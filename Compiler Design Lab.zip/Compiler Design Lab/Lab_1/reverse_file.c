#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *sourceFile, *destFile;
    long fileSize;
    char *buffer;
    int i;
    
    // Check if filenames are provided
    if (argc != 3) {
        printf("Usage: %s <source_file> <destination_file>\n", argv[0]);
        return 1;
    }
    
    // Open source file in read mode
    sourceFile = fopen(argv[1], "r");
    
    // Check if source file opened successfully
    if (sourceFile == NULL) {
        printf("Error: Could not open source file '%s'\n", argv[1]);
        return 1;
    }
    
    // Get file size using fseek and ftell
    fseek(sourceFile, 0, SEEK_END);  // Move to end of file
    fileSize = ftell(sourceFile);     // Get current position (file size)
    fseek(sourceFile, 0, SEEK_SET);  // Move back to beginning
    
    printf("\n========================================\n");
    printf("File Information:\n");
    printf("========================================\n");
    printf("Source file: %s\n", argv[1]);
    printf("File size:   %ld bytes\n", fileSize);
    printf("========================================\n\n");
    
    // Allocate memory for file contents
    buffer = (char *)malloc(fileSize + 1);
    if (buffer == NULL) {
        printf("Error: Memory allocation failed\n");
        fclose(sourceFile);
        return 1;
    }
    
    // Read entire file into buffer
    fread(buffer, 1, fileSize, sourceFile);
    buffer[fileSize] = '\0';  // Null terminate
    
    // Close source file
    fclose(sourceFile);
    
    // Open destination file in write mode
    destFile = fopen(argv[2], "w");
    if (destFile == NULL) {
        printf("Error: Could not create destination file '%s'\n", argv[2]);
        free(buffer);
        return 1;
    }
    
    // Write reversed content to destination file
    printf("Reversing file contents...\n");
    for (i = fileSize - 1; i >= 0; i--) {
        fputc(buffer[i], destFile);
    }
    
    // Close destination file
    fclose(destFile);
    
    // Free allocated memory
    free(buffer);
    
    printf("Success! Reversed content written to '%s'\n", argv[2]);
    printf("========================================\n\n");
    
    return 0;
}
