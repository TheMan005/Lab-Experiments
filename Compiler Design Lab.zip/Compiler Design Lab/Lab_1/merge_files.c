#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1024

int main(int argc, char *argv[]) {
    FILE *file1, *file2, *resultFile;
    char line1[MAX_LINE_LENGTH];
    char line2[MAX_LINE_LENGTH];
    int linesFromFile1 = 0, linesFromFile2 = 0;
    int file1End = 0, file2End = 0;
    
    // Check if filenames are provided
    if (argc != 4) {
        printf("Usage: %s <file1> <file2> <result_file>\n", argv[0]);
        return 1;
    }
    
    // Open first file in read mode
    file1 = fopen(argv[1], "r");
    if (file1 == NULL) {
        printf("Error: Could not open file '%s'\n", argv[1]);
        return 1;
    }
    
    // Open second file in read mode
    file2 = fopen(argv[2], "r");
    if (file2 == NULL) {
        printf("Error: Could not open file '%s'\n", argv[2]);
        fclose(file1);
        return 1;
    }
    
    // Open result file in write mode
    resultFile = fopen(argv[3], "w");
    if (resultFile == NULL) {
        printf("Error: Could not create result file '%s'\n", argv[3]);
        fclose(file1);
        fclose(file2);
        return 1;
    }
    
    printf("\n========================================\n");
    printf("Merging Files Alternately\n");
    printf("========================================\n");
    printf("File 1: %s\n", argv[1]);
    printf("File 2: %s\n", argv[2]);
    printf("Result: %s\n", argv[3]);
    printf("========================================\n\n");
    
    // Read and merge lines alternately
    while (!file1End || !file2End) {
        // Read line from first file
        if (!file1End) {
            if (fgets(line1, MAX_LINE_LENGTH, file1) != NULL) {
                fputs(line1, resultFile);
                linesFromFile1++;
            } else {
                file1End = 1;
            }
        }
        
        // Read line from second file
        if (!file2End) {
            if (fgets(line2, MAX_LINE_LENGTH, file2) != NULL) {
                fputs(line2, resultFile);
                linesFromFile2++;
            } else {
                file2End = 1;
            }
        }
    }
    
    // Close all files
    fclose(file1);
    fclose(file2);
    fclose(resultFile);
    
    // Display statistics
    printf("Merge completed successfully!\n");
    printf("----------------------------------------\n");
    printf("Lines from File 1: %d\n", linesFromFile1);
    printf("Lines from File 2: %d\n", linesFromFile2);
    printf("Total lines:       %d\n", linesFromFile1 + linesFromFile2);
    printf("----------------------------------------\n\n");
    
    return 0;
}
