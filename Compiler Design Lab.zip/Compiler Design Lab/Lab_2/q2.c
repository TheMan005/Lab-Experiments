#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *in, *out;
    char line[1024];

    in = fopen("input.c", "r");
    if (!in) {
        perror("Error opening input file");
        return 1;
    }

    out = fopen("output_directives.c", "w");
    if (!out) {
        perror("Error opening output file");
        fclose(in);
        return 1;
    }

    while (fgets(line, sizeof(line), in)) {
        if (line[0] != '#') {   // Skip preprocessor directives
            fputs(line, out);
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}

