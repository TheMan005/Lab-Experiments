#include    <stdio.h>   
#inclue 	<stdlib.h> 

int   main() {    
    int   x   =   10;    
    printf("Valueis	%d\n",   x);
    if (x	< 15){
    	printf("X is less than 15")}   
    return    0;    
}

