#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *in, *out;
    char ch, prev = '\0';

    in = fopen("input.c", "r");
    if (!in) {
        perror("Error opening input file");
        return 1;
    }

    out = fopen("output.c", "w");
    if (!out) {
        perror("Error opening output file");
        fclose(in);
        return 1;
    }

    while ((ch = fgetc(in)) != EOF) {
        if (ch == ' ' || ch == '\t') {
            if (prev != ' ') {
                fputc(' ', out);
                prev = ' ';
            }
        } else {
            fputc(ch, out);
            prev = ch;
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}

