#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKEN_LENGTH 100

// Statistics counters
int keywordCount = 0, identifierCount = 0, operatorCount = 0;
int specialSymbolCount = 0, numericalCount = 0, stringLiteralCount = 0;

// C Keywords
char *keywords[] = {
    "auto", "break", "case", "char", "const", "continue", "default", "do",
    "double", "else", "enum", "extern", "float", "for", "goto", "if",
    "int", "long", "register", "return", "short", "signed", "sizeof", "static",
    "struct", "switch", "typedef", "union", "unsigned", "void", "volatile", "while"
};
int numKeywords = 32;

// Function to check if a string is a keyword
int isKeyword(char *str) {
    for (int i = 0; i < numKeywords; i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

// Function to identify arithmetic operators
int isArithmeticOperator(char ch, char nextCh) {
    if (ch == '+' && nextCh == '+') {
        printf("Arithmetic Operator: ++\n");
        operatorCount++;
        return 2;
    }
    if (ch == '-' && nextCh == '-') {
        printf("Arithmetic Operator: --\n");
        operatorCount++;
        return 2;
    }
    if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%') {
        printf("Arithmetic Operator: %c\n", ch);
        operatorCount++;
        return 1;
    }
    return 0;
}

// Function to identify relational operators
int isRelationalOperator(char ch, char nextCh) {
    if (ch == '<' && nextCh == '=') {
        printf("Relational Operator: <=\n");
        operatorCount++;
        return 2;
    }
    if (ch == '>' && nextCh == '=') {
        printf("Relational Operator: >=\n");
        operatorCount++;
        return 2;
    }
    if (ch == '=' && nextCh == '=') {
        printf("Relational Operator: ==\n");
        operatorCount++;
        return 2;
    }
    if (ch == '!' && nextCh == '=') {
        printf("Relational Operator: !=\n");
        operatorCount++;
        return 2;
    }
    if (ch == '<') {
        printf("Relational Operator: <\n");
        operatorCount++;
        return 1;
    }
    if (ch == '>') {
        printf("Relational Operator: >\n");
        operatorCount++;
        return 1;
    }
    return 0;
}

// Function to identify logical operators
int isLogicalOperator(char ch, char nextCh) {
    if (ch == '&' && nextCh == '&') {
        printf("Logical Operator: &&\n");
        operatorCount++;
        return 2;
    }
    if (ch == '|' && nextCh == '|') {
        printf("Logical Operator: ||\n");
        operatorCount++;
        return 2;
    }
    if (ch == '!') {
        printf("Logical Operator: !\n");
        operatorCount++;
        return 1;
    }
    return 0;
}

// Function to identify special symbols
int isSpecialSymbol(char ch) {
    char specialSymbols[] = "();{}[],.:;";
    for (int i = 0; specialSymbols[i] != '\0'; i++) {
        if (ch == specialSymbols[i]) {
            printf("Special Symbol: %c\n", ch);
            specialSymbolCount++;
            return 1;
        }
    }
    if (ch == '=') {
        printf("Assignment Operator: =\n");
        operatorCount++;
        return 1;
    }
    return 0;
}

// Function to check if character is valid for identifier
int isValidIdentifierChar(char ch) {
    return isalnum(ch) || ch == '_';
}

// Function to identify and print identifier or keyword
void processIdentifier(char *token) {
    if (isKeyword(token)) {
        printf("Keyword: %s\n", token);
        keywordCount++;
    } else {
        printf("Identifier: %s\n", token);
        identifierCount++;
    }
}

// Function to check if a string is a numerical constant
int isNumericalConstant(char *str) {
    int hasDecimal = 0;
    int i = 0;
    
    if (str[0] == '\0') return 0;
    
    // Check for negative sign
    if (str[0] == '-' || str[0] == '+') {
        i = 1;
    }
    
    if (str[i] == '\0') return 0;
    
    for (; str[i] != '\0'; i++) {
        if (str[i] == '.') {
            if (hasDecimal) return 0;
            hasDecimal = 1;
        } else if (!isdigit(str[i])) {
            if (str[i] == 'f' || str[i] == 'F' || 
                str[i] == 'l' || str[i] == 'L') {
                return str[i+1] == '\0';
            }
            return 0;
        }
    }
    return 1;
}

// Function to process the C source file
void analyzeFile(char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file '%s'\n", filename);
        return;
    }
    
    char ch, nextCh;
    char token[MAX_TOKEN_LENGTH];
    int tokenIndex = 0;
    int inString = 0;
    int inComment = 0;
    int inLineComment = 0;
    
    printf("\n========================================\n");
    printf("LEXICAL ANALYSIS RESULTS\n");
    printf("File: %s\n", filename);
    printf("========================================\n\n");
    
    while ((ch = fgetc(file)) != EOF) {
        nextCh = fgetc(file);
        if (nextCh != EOF) {
            ungetc(nextCh, file);
        } else {
            nextCh = '\0';
        }
        
        // Handle comments
        if (ch == '/' && nextCh == '*') {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            inComment = 1;
            fgetc(file);
            continue;
        }
        if (inComment) {
            if (ch == '*' && nextCh == '/') {
                inComment = 0;
                fgetc(file);
            }
            continue;
        }
        if (ch == '/' && nextCh == '/') {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            inLineComment = 1;
            fgetc(file);
            continue;
        }
        if (inLineComment) {
            if (ch == '\n') {
                inLineComment = 0;
            }
            continue;
        }
        
        // Handle string literals
        if (ch == '"') {
            if (tokenIndex > 0 && !inString) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            
            if (!inString) {
                inString = 1;
                token[0] = '"';
                tokenIndex = 1;
            } else {
                token[tokenIndex++] = '"';
                token[tokenIndex] = '\0';
                printf("String Literal: %s\n", token);
                stringLiteralCount++;
                inString = 0;
                tokenIndex = 0;
            }
            continue;
        }
        
        if (inString) {
            if (tokenIndex < MAX_TOKEN_LENGTH - 1) {
                token[tokenIndex++] = ch;
            }
            continue;
        }
        
        // Check for operators (order matters!)
        int opLen;
        if ((opLen = isLogicalOperator(ch, nextCh)) > 0) {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            if (opLen == 2) fgetc(file);
            continue;
        }
        if ((opLen = isRelationalOperator(ch, nextCh)) > 0) {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            if (opLen == 2) fgetc(file);
            continue;
        }
        if ((opLen = isArithmeticOperator(ch, nextCh)) > 0) {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            if (opLen == 2) fgetc(file);
            continue;
        }
        
        // Check for special symbols
        if (isSpecialSymbol(ch)) {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
            continue;
        }
        
        // Build tokens
        if (isValidIdentifierChar(ch) || (ch == '.' && isdigit(nextCh))) {
            if (tokenIndex < MAX_TOKEN_LENGTH - 1) {
                token[tokenIndex++] = ch;
            }
        } else if (isspace(ch)) {
            if (tokenIndex > 0) {
                token[tokenIndex] = '\0';
                if (isNumericalConstant(token)) {
                    printf("Numerical Constant: %s\n", token);
                    numericalCount++;
                } else {
                    processIdentifier(token);
                }
                tokenIndex = 0;
            }
        } else if (ch == '#') {
            // Skip preprocessor directives for now
            while ((ch = fgetc(file)) != '\n' && ch != EOF);
        }
    }
    
    // Process last token if any
    if (tokenIndex > 0) {
        token[tokenIndex] = '\0';
        if (isNumericalConstant(token)) {
            printf("Numerical Constant: %s\n", token);
            numericalCount++;
        } else {
            processIdentifier(token);
        }
    }
    
    fclose(file);
    
    // Print statistics
    printf("\n========================================\n");
    printf("STATISTICS\n");
    printf("========================================\n");
    printf("Keywords:          %d\n", keywordCount);
    printf("Identifiers:       %d\n", identifierCount);
    printf("Operators:         %d\n", operatorCount);
    printf("Special Symbols:   %d\n", specialSymbolCount);
    printf("Numerical Constants: %d\n", numericalCount);
    printf("String Literals:   %d\n", stringLiteralCount);
    printf("========================================\n");
    printf("Total Tokens:      %d\n", 
           keywordCount + identifierCount + operatorCount + 
           specialSymbolCount + numericalCount + stringLiteralCount);
    printf("========================================\n\n");
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <C_source_file>\n", argv[0]);
        return 1;
    }
    
    analyzeFile(argv[1]);
    
    return 0;
}
