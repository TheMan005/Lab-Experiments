#include <stdio.h>

int main() {
    int a = 10, b = 20;
    float result = 3.14;
    char name[] = "Hello World";
    
    // This is a comment
    if (a < b && a != 0) {
        result = a + b * 2.5;
        printf("Result: %f\n", result);
    }
    
    /* Multi-line comment
       testing the analyzer */
    
    for (int i = 0; i <= 5; i++) {
        a++;
        b--;
    }
    
    while (a > 0 || b < 100) {
        a = a - 1;
    }
    
    return 0;
}
